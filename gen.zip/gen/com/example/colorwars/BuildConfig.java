/** Automatically generated file. DO NOT MODIFY */
package com.example.colorwars;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}